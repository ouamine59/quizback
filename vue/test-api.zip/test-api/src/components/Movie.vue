<template lang="">
    <div class="movie" v-if="id<=9">
 
        <div class="animate">{{id+1}}</div>

        <img :src="`http://image.tmdb.org/t/p/w500/${movie.poster_path}`"/>
       <h1>{{movie.original_title}}</h1>
        
        <div class="score">Score : {{movie.vote_average}}</div>
        
    </div>
</template>
<script setup>
    import { defineProps , defineEmits } from 'vue'; 
    const props = defineProps({
        movie : Object,
        id : Number
    })
</script>
<style lang="scss">

    .movie{
        width:400px;
        border:1px solid grey;
        border-radius: 40px;
        margin: 25px;
        box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;
        position:relative;
    }
    img{
        width:100%;
        border-radius: 40px 40px 0px 0px;
    }
    .score{
        font-size: 20px;
    }
    .animate{
        position: absolute;
        width:60px;
        height:60px;
        background-color: red;
        display:flex;
        justify-content: center;
        align-items: center;
        border-radius: 50%;
        color:white;
        font-weight: bold;
        top:-15px;
        left:-20px;
    }
</style>