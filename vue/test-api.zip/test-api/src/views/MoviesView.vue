<template>
    <div class="home">
        <Movie v-for="(movie, index ) in tabMovie" :key="index"
        :movie="movie"
        :id="index"/>
    </div>
</template>
  
  <script setup>
  // @ is an alias to /src
  import Movie from '@/components/Movie.vue'
  import axios from "axios" ;
  import { ref } from 'vue';
  const tabMovie = ref([]);
  const listMovie = async ()=>{
    const options = {
        method: 'GET',
        headers: {
            accept: 'application/json',
            Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIyZjZjMWJhYWFiMzVlNDY3MGY3ODE5MWZmZmZjMWRhMCIsIm5iZiI6MTcyNDM5NDk2OC41MTY2MzgsInN1YiI6IjY1OTZjNTAyNWNjMTFkNzhhMzdkMWE0ZiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.RWBoaAbi8RSE6QLOAaBvgQmt-OdE_VR8zKbpjOKwXpM'
        }
     };
    axios.get('https://api.themoviedb.org/3/movie/popular?language=en-US&page=1', options)
    .then(response => {
        // Tri des films par `vote_average` en ordre décroissant
        tabMovie.value = response.data.results.sort((a, b) => b.vote_average - a.vote_average);
    })
    .catch(err => console.error(err));
    
    
    }
   listMovie()
  </script>
  <style lang="scss">
  .home{
      display:flex;
      justify-content: space-around;
      flex-wrap: wrap;

  }
</style>
  